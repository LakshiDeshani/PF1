package com.example.footwareclient

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
