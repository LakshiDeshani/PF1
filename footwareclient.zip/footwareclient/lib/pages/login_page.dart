import 'package:flutter/material.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.maxFinite,padding:const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color:Colors.blue,
        ),
        child:Column(
          mainAxisAlignment:MainAxisAlignment.center,
          children: [const Text(
            'welcome Back!',
            style: TextStyle(
              fontSize:28,
              fontWeight: FontWeight.bold,
              color:Colors.deepPurple,
            ),
            child:Column(
              MainAxisAlignment:MainAxisAlignment.center,
              children:[
                const Text(),
                const SizedBox(),

                TextField(),
                const SizedBox,
                ElevatedButton(onPressed: , child: child)
                TextButton(onPressed:() {},
                child:const Text('Register new Account'))
              ]
            )
          )],
        )
      ),
    );
  }
}

class Colum {
  const Colum();
}
